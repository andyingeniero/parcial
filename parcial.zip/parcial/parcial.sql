﻿# Host: localhost  (Version: 5.5.24-log)
# Date: 2016-03-15 21:53:57
# Generator: MySQL-Front 5.3  (Build 4.123)

/*!40101 SET NAMES utf8 */;

#
# Structure for table "departamento"
#

DROP TABLE IF EXISTS `departamento`;
CREATE TABLE `departamento` (
  `Id` int(11) NOT NULL AUTO_INCREMENT,
  `nombre` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`Id`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=latin1;

#
# Data for table "departamento"
#

INSERT INTO `departamento` VALUES (1,'administrador');

#
# Structure for table "empleado"
#

DROP TABLE IF EXISTS `empleado`;
CREATE TABLE `empleado` (
  `Idempleado` int(11) NOT NULL AUTO_INCREMENT,
  `nombre` varchar(40) DEFAULT NULL,
  `apellidos` varchar(255) DEFAULT NULL,
  `departamento` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`Idempleado`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=latin1;

#
# Data for table "empleado"
#

INSERT INTO `empleado` VALUES (1,'andy manuel','hernandez cassiani','1');
