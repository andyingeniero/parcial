/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Dao.Imp;

import com.demo.db.DbConnectionFactory;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;
import java.util.logging.Level;
import java.util.logging.Logger;
import modelo.DaoDepartamento;
import modelo.Departamento;

/**
 *
 * @author Gatocell
 */
public class DaoDepartamentoImp implements DaoDepartamento<Departamento> {

    public DaoDepartamentoImp() {
        try {
            DbConnectionFactory.connect();
        } catch (ClassNotFoundException | SQLException ex) {
            Logger.getLogger(DaoDepartamentoImp.class.getName()).log(Level.SEVERE, null, ex);
        }
    }

    @Override
    public void guardar(Departamento departamento) {
        Connection connection = DbConnectionFactory.getConnection();
        try {
            PreparedStatement pst = connection.prepareStatement("Insert into departamento values(?,?)");
            pst.setInt(1, 0);
            pst.setString(2, departamento.getNombre());
            pst.executeUpdate();
        } catch (SQLException ex) {
            Logger.getLogger(DaoDepartamentoImp.class.getName()).log(Level.SEVERE, null, ex);
        }

    }

    @Override
    public void actualizar(Departamento departamento) {

        Connection connection = DbConnectionFactory.getConnection();
        try {
            PreparedStatement pst = connection.prepareStatement("UPDATE departamento SET nombre = ? WHERE id = ? ");
            pst.setInt(2, departamento.getId());
            pst.setString(1, departamento.getNombre());
            pst.executeUpdate();
        } catch (SQLException ex) {
            Logger.getLogger(DaoEmpleadoImp.class.getName()).log(Level.SEVERE, null, ex);
        }
    }

    @Override
    public List<Departamento> listar() {
        List<Departamento> lista = new ArrayList<>();
        try {
            Connection connection = DbConnectionFactory.getConnection();
            PreparedStatement pst = connection.prepareStatement("Select * from departamento");
            ResultSet rs = pst.executeQuery();
            while (rs.next()) {
                Departamento departamento = new Departamento();
                departamento.setId(rs.getInt(1));
                departamento.setNombre(rs.getString(2));
                lista.add(departamento);
            }
        } catch (SQLException ex) {
            Logger.getLogger(DaoEmpleadoImp.class.getName()).log(Level.SEVERE, null, ex);
        }
        return lista;
    }

    @Override
    public void eliminar(Departamento departamento) {
        try {
            Connection connection = DbConnectionFactory.getConnection();
            PreparedStatement pst = connection.prepareStatement("DELETE FROM departamento WHERE id= ?");
            pst.setInt(1, departamento.getId());
            pst.executeUpdate();
        } catch (SQLException ex) {
            Logger.getLogger(DaoEmpleadoImp.class.getName()).log(Level.SEVERE, null, ex);
        }
    }

}
