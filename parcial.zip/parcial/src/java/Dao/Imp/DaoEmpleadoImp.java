/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Dao.Imp;

import com.demo.db.DbConnectionFactory;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;
import java.util.logging.Level;
import java.util.logging.Logger;
import modelo.DaoEmpleado;
import modelo.Departamento;
import modelo.Empleado;

/**
 *
 * @author Gatocell
 */
public class DaoEmpleadoImp implements DaoEmpleado<Empleado> {

    public DaoEmpleadoImp() {
        try {
            DbConnectionFactory.connect();
        } catch (ClassNotFoundException | SQLException ex) {
            Logger.getLogger(DaoEmpleadoImp.class.getName()).log(Level.SEVERE, null, ex);
        }
    }

    @Override
    public void guardar(Empleado empleado) {
        Connection connection = DbConnectionFactory.getConnection();
        try {
            PreparedStatement pst = connection.prepareStatement("Insert into empleado values(?,?,?,?)");
            pst.setInt(1, 0);
            pst.setString(2, empleado.getNombre());
            pst.setString(3, empleado.getApellidos());
            pst.setInt(4, empleado.getDepartamento().getId());
            pst.executeUpdate();
        } catch (SQLException ex) {
            Logger.getLogger(DaoEmpleadoImp.class.getName()).log(Level.SEVERE, null, ex);
        }

    }

    @Override
    public void actualizar(Empleado empleado) {

        Connection connection = DbConnectionFactory.getConnection();
        try {
            PreparedStatement pst = connection.prepareStatement("UPDATE empleado SET nombre = ?, apellidos = ?, departamento = ? WHERE idempleado = ? ");
            pst.setInt(4, empleado.getIdempleado());
            pst.setString(1, empleado.getNombre());
            pst.setString(2, empleado.getApellidos());
            pst.setInt(3, empleado.getDepartamento().getId());
            pst.executeUpdate();
        } catch (SQLException ex) {
            Logger.getLogger(DaoEmpleadoImp.class.getName()).log(Level.SEVERE, null, ex);
        }
    }

    @Override
    public List<Empleado> listar() {
        List<Empleado> lista = new ArrayList<>();
        try {
            Connection connection = DbConnectionFactory.getConnection();
            PreparedStatement pst = connection.prepareStatement("Select * from empleado e inner join departamento d on d.id = e.departamento order by idempleado ");
            ResultSet rs = pst.executeQuery();
            while (rs.next()) {
                Empleado empleado = new Empleado();
                empleado.setDepartamento(new Departamento());
                empleado.setIdempleado(rs.getInt(1));
                empleado.setNombre(rs.getString(2));
                empleado.setApellidos(rs.getString(3));
                empleado.getDepartamento().setNombre(rs.getString(6));
                lista.add(empleado);

            }
        } catch (SQLException ex) {
            Logger.getLogger(DaoEmpleadoImp.class.getName()).log(Level.SEVERE, null, ex);
        }
        return lista;
    }

     @Override
    public void eliminar(Empleado empleado) {
        Connection connection = DbConnectionFactory.getConnection();
        try {           
            PreparedStatement pst = connection.prepareStatement("DELETE FROM empleado WHERE idempleado= ?");
            pst.setInt(1, empleado.getIdempleado());
            pst.executeUpdate();
        } catch (SQLException ex) {
            Logger.getLogger(DaoEmpleadoImp.class.getName()).log(Level.SEVERE, null, ex);
        }
    }

}
