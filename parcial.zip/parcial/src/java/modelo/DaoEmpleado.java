/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package modelo;


import java.util.List;

/**
 *
 *
 * @param <Empleado>
 */
public interface DaoEmpleado<Empleado> {
    void guardar(Empleado empleado);
    void actualizar(Empleado empleado);
    List<Empleado> listar();
    void eliminar(Empleado empleado);
    
}
 
