/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package web;

import Dao.Imp.DaoDepartamentoImp;
import Dao.Imp.DaoEmpleadoImp;
import java.io.Serializable;
import java.util.ArrayList;
import java.util.List;
import javax.faces.application.FacesMessage;
import javax.faces.bean.ManagedBean;
import javax.faces.bean.ViewScoped;
import javax.faces.context.FacesContext;
import modelo.DaoDepartamento;
import modelo.DaoEmpleado;
import modelo.Departamento;
import modelo.Empleado;
import org.primefaces.context.RequestContext;

/**
 *
 * @author Gatocell
 */
@ManagedBean
@ViewScoped
public class EmpleadoManagerBean implements Serializable {

    private Empleado empleado = new Empleado();
    private List<Empleado> empleados = new ArrayList<>();
    private List<Departamento> departamentos = new ArrayList<>();

    public Empleado getEmpleado() {
        return empleado;
    }

    public void setEmpleado(Empleado empleado) {
        this.empleado = empleado;
    }

    public List<Empleado> getEmpleados() {
        return empleados;
    }

    public void setEmpleados(List<Empleado> Empleados) {
        this.empleados = empleados;
    }

    private DaoEmpleado<Empleado> dao = new DaoEmpleadoImp();
    private DaoDepartamento<Departamento> daoD = new DaoDepartamentoImp();

    
    public boolean validarCampos() {
        boolean rpta = true;
        if (empleado.getNombre() == null || empleado.getNombre().isEmpty() ) {
            rpta = false;
        }
        if (empleado.getApellidos() == null ||empleado.getApellidos().isEmpty()) {
            rpta = false;
        }
        if (empleado.getDepartamento() == null ||empleado.getDepartamento().getId() == 0) {
            rpta = false;
        }
        return rpta;
    }

    public void guardarEmpleado() {
        if (validarCampos()) {
            if (empleado.getIdempleado()== null) {
                FacesContext faces = FacesContext.getCurrentInstance();
                dao.guardar(empleado);
                empleados = dao.listar();
                departamentos =daoD.listar();
                faces.addMessage(null, new FacesMessage(FacesMessage.SEVERITY_INFO, "Informacion", "Registro EXitoso"));
                empleado  = new Empleado();
                empleado.setDepartamento(new Departamento());
            } else {
                FacesContext faces = FacesContext.getCurrentInstance();
                dao.actualizar(empleado);
                empleados = dao.listar();
                departamentos =daoD.listar();
                faces.addMessage(null, new FacesMessage(FacesMessage.SEVERITY_INFO, "Informacion", "Edición EXitosa"));
            }
        } else {
            FacesContext faces = FacesContext.getCurrentInstance();
            faces.addMessage(null, new FacesMessage(FacesMessage.SEVERITY_WARN, "Advertencia", "Existen datos sin diligenciar"));
        }

    }

    public void onEditarEmpleado(Empleado aux) {
        empleado.setDepartamento(new Departamento());
        empleado.setIdempleado(aux.getIdempleado());
        empleado.setApellidos(aux.getApellidos());
        empleado.setNombre(aux.getNombre());
        empleado.setDepartamento(aux.getDepartamento());
        RequestContext.getCurrentInstance().update("campos");
    }

    public void onLimpiarFormulario() {
        empleado = new Empleado();
        empleado.setDepartamento(new Departamento());
        RequestContext.getCurrentInstance().update("campos");
    }  
    
    public void onEliminarEmpleado(Empleado aux) {
        FacesContext faces = FacesContext.getCurrentInstance();
        dao.eliminar(aux);
        empleados = dao.listar();
        RequestContext.getCurrentInstance().update("campos growl");
        empleado = new Empleado();
        empleado.setDepartamento(new Departamento());
        faces.addMessage(null, new FacesMessage(FacesMessage.SEVERITY_INFO, "Informacion", "Eliminación EXitosa"));
    } 
    
    public EmpleadoManagerBean() {
        empleado.setDepartamento(new Departamento());
        empleados = dao.listar();
        departamentos = daoD.listar();
    }

    public List<Departamento> getDepartamentos() {
        return departamentos;
    }

    public void setDepartamentos(List<Departamento> departamentos) {
        this.departamentos = departamentos;
    }

}
