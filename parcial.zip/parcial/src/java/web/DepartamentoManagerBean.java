/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package web;

import Dao.Imp.DaoDepartamentoImp;
import java.io.Serializable;
import java.util.ArrayList;
import java.util.List;
import javax.faces.application.FacesMessage;
import javax.faces.bean.ManagedBean;
import javax.faces.bean.ViewScoped;
import javax.faces.context.FacesContext;
import modelo.DaoDepartamento;
import modelo.Departamento;
import org.primefaces.context.RequestContext;

/**
 *
 * @author Gatocell
 */
@ManagedBean
@ViewScoped
public class DepartamentoManagerBean implements Serializable {

    private Departamento departamento = new Departamento();
    private List<Departamento> departamentos = new ArrayList<>();
    private DaoDepartamento<Departamento> daoD = new DaoDepartamentoImp();

    public boolean validarCampos() {
        boolean rpta = true;
        if (departamento.getNombre() == null || departamento.getNombre().isEmpty()) {
            rpta = false;
        }
        return rpta;
    }

    public void guardarDepartamento() {
        if (validarCampos()) {
            if (departamento.getId() == null) {
                FacesContext faces = FacesContext.getCurrentInstance();
                daoD.guardar(departamento);
                departamentos = daoD.listar();
                faces.addMessage(null, new FacesMessage(FacesMessage.SEVERITY_INFO, "Informacion", "Registro EXitoso"));
                departamento = new Departamento();
            } else {
                FacesContext faces = FacesContext.getCurrentInstance();
                daoD.actualizar(departamento);
                departamentos = daoD.listar();
                faces.addMessage(null, new FacesMessage(FacesMessage.SEVERITY_INFO, "Informacion", "Edición EXitosa"));
            }
        } else {
            FacesContext faces = FacesContext.getCurrentInstance();
            faces.addMessage(null, new FacesMessage(FacesMessage.SEVERITY_WARN, "Advertencia", "Existen datos sin diligenciar"));
        }

    }

    public void onEditarDepartamento(Departamento aux) {
        departamento.setId(aux.getId());
        departamento.setNombre(aux.getNombre());
        RequestContext.getCurrentInstance().update("campos");
    }

    public void onLimpiarFormulario() {
        departamento = new Departamento();
        RequestContext.getCurrentInstance().update("campos");
    }

    public void onEliminarDepartamento(Departamento aux) {
        FacesContext faces = FacesContext.getCurrentInstance();
        daoD.eliminar(aux);
        departamentos = daoD.listar();
        RequestContext.getCurrentInstance().update("campos growl");
        departamento = new Departamento();
        faces.addMessage(null, new FacesMessage(FacesMessage.SEVERITY_INFO, "Informacion", "Eliminación EXitosa"));
    }

    public DepartamentoManagerBean() {
        departamento = new Departamento();
        departamentos = daoD.listar();
    }

    public List<Departamento> getDepartamentos() {
        return departamentos;
    }

    public void setDepartamentos(List<Departamento> departamentos) {
        this.departamentos = departamentos;
    }

    public Departamento getDepartamento() {
        return departamento;
    }

    public void setDepartamento(Departamento departamento) {
        this.departamento = departamento;
    }

}
